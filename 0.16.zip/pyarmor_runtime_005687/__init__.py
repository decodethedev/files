# Pyarmor 8.5.7 (pro), 005687, 2024-06-14T06:52:51.979217
from .pyarmor_runtime import __pyarmor__
